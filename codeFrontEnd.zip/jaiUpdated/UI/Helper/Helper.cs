﻿using System.Net.Http;

namespace FrontEnd.Helper
{
    public class CodeHelper
    {
        public HttpClient initial()
        {
            var client = new HttpClient();
            client.BaseAddress = new System.Uri("http://codeapi-dev.us-east-1.elasticbeanstalk.com");
            return client;
            //https://34.149.94.52.nip.io/codeapi
            //"http://codeapi-dev.us-east-1.elasticbeanstalk.com/"

            //
        }
    }
}
