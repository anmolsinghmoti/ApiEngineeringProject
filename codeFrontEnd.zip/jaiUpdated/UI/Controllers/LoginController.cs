﻿using FrontEnd.Helper;
using Microsoft.AspNetCore.Mvc;
using Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace FrontEnd.Controllers
{
    public class LoginController : Controller
    {
        CodeHelper _helper = new CodeHelper();
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> LoginAsync(Client myClient)
        {
            
            System.Collections.Generic.List<Client> clients = new List<Client>();
            HttpClient client = _helper.initial();
            HttpResponseMessage response = await client.GetAsync("/api/clients");
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                clients = JsonConvert.DeserializeObject<List<Client>>(result);
                foreach (var item in clients)
                {
                    if (item.ClientEmail.Equals(myClient.ClientEmail) && item.ClientPassword.Equals(myClient.ClientPassword))
                    {
                        ViewData["MyClientId"] = item.ClientId;
                        return RedirectToAction("index", "Tutorial");
                    }
                }

            }
            return View();
        }

    }
}
