﻿using FrontEnd.Helper;
using Microsoft.AspNetCore.Mvc;
using Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace FrontEnd.Controllers
{
    public class ClientController : Controller
    {
        int clientId;
        CodeHelper _helper = new CodeHelper();
        public async Task<IActionResult> Index()
        {
            List<Client> clients = new List<Client>();
            HttpClient client = _helper.initial();
            HttpResponseMessage response = await client.GetAsync("/api/clients");
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                clients = JsonConvert.DeserializeObject<List<Client>>(result);
            }
            return View(clients);
        }
        [HttpGet]
        public async Task<IActionResult> GetClientById(int id)
        {
            TempData["ClientId"] = id;

            Client clients = new Client();
            HttpClient client = _helper.initial();
            HttpResponseMessage response = await client.GetAsync("/api/Client/" + id);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                clients = JsonConvert.DeserializeObject<Client>(result);
            }
            return View(clients);
        }



        [HttpGet]

        public async Task<IActionResult> CreateClient()
        {

            return View();
        }

        [HttpPost]
            public async Task<IActionResult> CreateClient(Client myClient)
        {

            List<Client> clientsList = new List<Client>();
            //HttpClient client = _helper.initial();
      
            StringContent content=new StringContent(JsonConvert.SerializeObject(myClient),Encoding.UTF8,"application/json");
            Client clients = new Client();
            using (HttpClient client = _helper.initial())
            {
                HttpResponseMessage getResponse = await client.GetAsync("/api/clients");
                var getResult = getResponse.Content.ReadAsStringAsync().Result;
                clientsList = JsonConvert.DeserializeObject<List<Client>>(getResult);
                foreach (var item in clientsList)
                {
                    if (!item.ClientEmail.Equals(myClient.ClientEmail))
                    {
                        HttpResponseMessage response = await client.PostAsync("/api/newClient", content);
                        if (response.IsSuccessStatusCode)
                        {
                            var result = response.Content.ReadAsStringAsync().Result;
                            clients = JsonConvert.DeserializeObject<Client>(result);
                           
                        }
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        TempData["TempWarning"] = "Already registered.";
                        ViewData["warning"] = "Already registered.";
                        return RedirectToAction("CreateClient");

                    }
                }

            
             
            }

            
         
            return RedirectToAction("Index");
        }


        [HttpGet]
        public async Task<IActionResult> UpdateClient(int id)
        {
            clientId = id;
            Client clients = new Client();
            HttpClient client = _helper.initial();
            HttpResponseMessage response = await client.GetAsync("/api/Client/" + id);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                clients = JsonConvert.DeserializeObject<Client>(result);
            }

            return View(clients);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateClient(Client myClient)
        {

            StringContent content = new StringContent(JsonConvert.SerializeObject(myClient), Encoding.UTF8, "application/json");
            Client clients = new Client();
            using (HttpClient client = _helper.initial())
            {
                HttpResponseMessage response = await client.PutAsync("/api/Client/"+ myClient.ClientId+"/updateclient" , content);
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    clients = JsonConvert.DeserializeObject<Client>(result);
                }
            }



            return RedirectToAction("Index");
        }


        public async Task<IActionResult> DeleteClient(int id)
        {
            clientId = id;
            Client clients = new Client();
            HttpClient client = _helper.initial();
            HttpResponseMessage response = await client.DeleteAsync("/api/Client/"+id+"/api/client");
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                //clients = JsonConvert.DeserializeObject<Client>(result);
            }

            return RedirectToAction("Index");
        }

    }
}
