﻿using Amazon.S3.Transfer;
using FrontEnd.Helper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Amazon.S3;
using Amazon.Runtime;
using Microsoft.Extensions.Configuration;
using Amazon;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace FrontEnd.Controllers
{
    public class TutorialController : Controller
    {
      
        //readonly private UserManager<App> userManager;
        readonly CodeHelper _helper = new CodeHelper();
        [Authorize]
        public async Task<IActionResult> Index()
        {

            List<Tutorial> tutorials = new List<Tutorial>();
            HttpClient client = _helper.initial();
           var response = await client.GetAsync("/api/tutorials");
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                tutorials = JsonConvert.DeserializeObject<List<Tutorial>>(result);
            }
            return View(tutorials);
           
        }


        public async Task<IActionResult> CreateTutorial()
        {

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateTutorial(Tutorial myTutorial, IFormFile file)
        {
            BasicAWSCredentials credentials;
            AmazonS3Client amazonClient = new AmazonS3Client();
            try
            {
             
                StringContent content = new StringContent(JsonConvert.SerializeObject(myTutorial), Encoding.UTF8, "application/json");
                Tutorial tutorial = new Tutorial();
                using (HttpClient client = _helper.initial())
                {
                    HttpResponseMessage response = await client.PostAsync("/api/newTutorial", content);
                    if (response.IsSuccessStatusCode)
                    {
                        var result = response.Content.ReadAsStringAsync().Result;
                        tutorial = JsonConvert.DeserializeObject<Tutorial>(result);
                    }
                }

                //to upload video in s3

                var builder = new ConfigurationBuilder()
                                    .SetBasePath(Directory.GetCurrentDirectory())
                                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

                var accessKeyID = builder.Build().GetSection("AWSCredentials").GetSection("AccesskeyID").Value;
                var secretKey = builder.Build().GetSection("AWSCredentials").GetSection("Secretaccesskey").Value;

                credentials = new BasicAWSCredentials(accessKeyID, secretKey);
                amazonClient = new AmazonS3Client(credentials, RegionEndpoint.USEast1);
                await using var newMemoryStream = new MemoryStream();
                file.CopyTo(newMemoryStream);

                var uploadRequest = new TransferUtilityUploadRequest
                {
                    InputStream = newMemoryStream,
                    Key = myTutorial.TutorialName,

                    BucketName = "awsmovieshelf",
                    // CannedACL = S3CannedACL.PublicRead
                };
                var fileTransferUtility = new TransferUtility(amazonClient);
                await fileTransferUtility.UploadAsync(uploadRequest);


                return RedirectToAction("Index");
            }
            catch(Exception e)
            {
                return RedirectToAction("Index");
            }

        }

        public async Task<IActionResult> RegisterClientforTutorial(int? id)
        {

            var ClientId = (int)TempData["ClientId"];
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            /* var user = await UserManager.;*/
            // var userId = user?.Id;
            ClientTutorial clientTutorial = new ClientTutorial();
            clientTutorial.ClientId=ClientId;
            clientTutorial.TutorialId = id;
            var userName = User.FindFirstValue(ClaimTypes.Name);
            //ClientT clients = new Client();
            using (HttpClient client = _helper.initial())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(clientTutorial), Encoding.UTF8, "application/json");


                HttpResponseMessage response = await client.PostAsync("/api/newClientTutorial", content);
                        if (response.IsSuccessStatusCode)
                        {
                            var result = response.Content.ReadAsStringAsync().Result;
                            //clients = JsonConvert.DeserializeObject<Client>(result);

                        }
                        return RedirectToAction("Index");
                
                }



            }

        public async Task<IActionResult> DeleteTutorial(int id)
        {
 
            HttpClient client = _helper.initial();
            HttpResponseMessage response = await client.DeleteAsync("/api/Tutorial/api/tutorial/" + id);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                //clients = JsonConvert.DeserializeObject<Client>(result);
            }

            return RedirectToAction("Index");
        }

    }
}
