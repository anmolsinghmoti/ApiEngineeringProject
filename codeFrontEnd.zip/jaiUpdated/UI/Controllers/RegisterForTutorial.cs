﻿using Microsoft.AspNetCore.Mvc;

namespace FrontEnd.Controllers
{
    public class RegisterForTutorial : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
