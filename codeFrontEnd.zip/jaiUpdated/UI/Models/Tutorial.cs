﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace Models
{
    public partial class Tutorial
    {
        public Tutorial()
        {
            Clients = new HashSet<Client>();
            TutorialComments = new HashSet<TutorialComment>();
        }

        public int TutorialId { get; set; }
        [Required]
        public string TutorialName { get; set; }
        [Required]
        public string TutorialDescription { get; set; }
        [Required]
        public string TutorialLanguagePreference { get; set; }
        [Required]
        public int TutorialHours { get; set; }

        public virtual ICollection<Client> Clients { get; set; }
        public virtual ICollection<TutorialComment> TutorialComments { get; set; }
    }
}
